import React from 'react';


function TestComponent() {
    return (
        <div className="container">
             <div className="row justify-content-center">
                 <div className="col-md-8">
                     <div className="p-5 border border-primary">
                            <h2>Este elemento es un componente de React.</h2>
                        </div>
                 </div>
             </div>
         </div>
    );
}

export default TestComponent;
