import * as React from "react";

export default function Dashboard() {
    return (
        <div>
            <h1>
                Dashboard Component!
            </h1>
        </div>
    )
}
