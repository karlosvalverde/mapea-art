@extends("layouts.app")

@section("left_column")

<div class="container bg-warning">
    <h2>Es un Test!</h2>
</div>
@endsection

{{-- <form action="{{ route('researchers.search') }}" method="GET">
    @csrf
    <input type="text" name="query" class="form-control" />
    <input type="submit" class="btn btn-sm btn-primary" value="Search" style="margin-top: 10px;" />
</form> --}}
